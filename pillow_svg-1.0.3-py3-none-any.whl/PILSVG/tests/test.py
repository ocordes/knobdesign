from unittest import TestCase
from PILSVG import SVG

class TestSkia(TestCase):
    def test_to_png(self):
        self.assertTrue(1 == 1)